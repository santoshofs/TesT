angular.module('book', []).controller('authorcntrl', function($scope) {
    $scope.titles = [
        {title:'Alphabets',author:'Mohan',price:'100'},
        {title:'HTML',author:'Sabari',price:'80'},
		    {title:'CSS',author:'sabari',price:'80'},
        {title:'HTML5',author:'sabari',price:'80'},
        {title:'test',author:'yyy',price:'56'},
        {title:'CSS3',author:'sabari',price:'80'},
        {title:'Jquery',author:'Kowdal',price:'60'},
        {title:'AngularJs',author:'Mainik',price:'80'},
        {title:'test1',author:'aaa',price:'54'},
        {title:'test',author:'uuuu',price:'87'},
        {title:'testn',author:'zzz',price:'68'},
        ];
    $scope.orderByMe = function(x) {
        $scope.myOrderBy = x;
    }
});
